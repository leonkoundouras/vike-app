#!/usr/bin/env node

// Plesk Node.js entry point
// This file should be set as the "Application Startup File" in Plesk

import './server-production.js'